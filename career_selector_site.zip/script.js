function suggestCareers() {
    let choices = document.querySelectorAll("#quiz-form input:checked");
    let careerList = document.getElementById("career-list");
    careerList.innerHTML = "";  

    let careerSuggestions = {
        math: ["Инженер", "Бағдарламашы", "Математик"],
        art: ["Дизайнер", "Суретші", "Архитектор"],
        tech: ["Бағдарламашы", "Жасанды интеллект маманы", "IT маманы"],
        writing: ["Журналист", "Копирайтер", "Редактор"],
        science: ["Физик", "Биолог", "Химик"],
        music: ["Музыкант", "Композитор", "Әнші"],
        sports: ["Спортшы", "Фитнес жаттықтырушысы", "Дене тәрбиесі мұғалімі"]
    };

    choices.forEach(choice => {
        let careers = careerSuggestions[choice.value] || [];
        careers.forEach(career => {
            let li = document.createElement("li");
            li.textContent = career;
            careerList.appendChild(li);
        });
    });

    if (careerList.innerHTML === "") {
        careerList.innerHTML = "<li>Мамандық таңдауға көмектесу үшін хоббилеріңді белгіле</li>";
    }
}
